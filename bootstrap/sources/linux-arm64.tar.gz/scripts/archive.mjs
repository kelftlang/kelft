import fs from 'node:fs';
import zlib from 'node:zlib';
import {requireThat, safeName} from './common.mjs';

const MAX = 512 << 20;
function data(row) {
  const bytes = row.data ?? fs.readFileSync(row.file);
  requireThat(bytes.length <= 256 << 20, 'Archive member exceeds bound'); return bytes;
}
export function tarGzip(rows) {
  const chunks = []; let total = 1024;
  for (const row of rows) {
    safeName(row.path); const bytes = data(row), header = Buffer.alloc(512);
    let name = row.path, prefix = '';
    if (Buffer.byteLength(name) > 100) { const at = name.lastIndexOf('/'); prefix = name.slice(0, at); name = name.slice(at + 1); }
    requireThat(Buffer.byteLength(name) <= 100 && Buffer.byteLength(prefix) <= 155, 'USTAR name exceeds bound');
    header.write(name, 0, 100); header.write(prefix, 345, 155);
    const oct = (at, length, value) => header.write(value.toString(8).padStart(length - 1, '0') + '\0', at, length, 'ascii');
    oct(100, 8, row.mode ?? 0o644); oct(108, 8, 0); oct(116, 8, 0); oct(124, 12, bytes.length); oct(136, 12, 0);
    header.fill(32, 148, 156); header[156] = 48; header.write('ustar\0', 257, 6); header.write('00', 263, 2);
    header.write(header.reduce((a,b) => a+b, 0).toString(8).padStart(6, '0') + '\0 ', 148, 8);
    const padding = (512 - bytes.length % 512) % 512; total += 512 + bytes.length + padding;
    requireThat(total <= MAX, 'Archive exceeds bound'); chunks.push(header, bytes, Buffer.alloc(padding));
  }
  chunks.push(Buffer.alloc(1024)); const result = zlib.gzipSync(Buffer.concat(chunks), {level: 9, mtime: 0}); result[9] = 255; return result;
}
const crcTable = Array.from({length: 256}, (_, n) => { for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ n >>> 1 : n >>> 1; return n >>> 0; });
function crc32(bytes) { let crc = 0xffffffff; for (const n of bytes) crc = crcTable[(crc ^ n) & 255] ^ crc >>> 8; return (crc ^ 0xffffffff) >>> 0; }
export function zip(rows) {
  requireThat(rows.length <= 8192, 'ZIP entry bound'); const parts = [], directory = []; let offset = 0;
  for (const row of rows) {
    safeName(row.path); const name = Buffer.from(row.path), bytes = data(row), compressed = zlib.deflateRawSync(bytes, {level: 9}), crc = crc32(bytes);
    const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x800, 6); local.writeUInt16LE(8, 8); local.writeUInt16LE(33, 12);
    local.writeUInt32LE(crc, 14); local.writeUInt32LE(compressed.length, 18); local.writeUInt32LE(bytes.length, 22); local.writeUInt16LE(name.length, 26);
    const central = Buffer.alloc(46); central.writeUInt32LE(0x02014b50); central.writeUInt16LE(0x314, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(0x800, 8); central.writeUInt16LE(8, 10); central.writeUInt16LE(33, 14);
    central.writeUInt32LE(crc, 16); central.writeUInt32LE(compressed.length, 20); central.writeUInt32LE(bytes.length, 24); central.writeUInt16LE(name.length, 28); central.writeUInt32LE(((0o100000 | (row.mode ?? 0o644)) << 16) >>> 0, 38); central.writeUInt32LE(offset, 42);
    parts.push(local, name, compressed); directory.push(central, name); offset += local.length + name.length + compressed.length; requireThat(offset <= MAX, 'ZIP exceeds bound');
  }
  const index = Buffer.concat(directory), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50); end.writeUInt16LE(rows.length, 8); end.writeUInt16LE(rows.length, 10); end.writeUInt32LE(index.length, 12); end.writeUInt32LE(offset, 16);
  requireThat(offset + index.length + 22 <= MAX, 'ZIP exceeds bound'); return Buffer.concat([...parts, index, end]);
}
